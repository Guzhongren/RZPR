/* jshint unused: false */
var

//apiUrl: String
//    the URL of the ArcGIS API for JavaScript, you can change it to point to your own API.

apiUrl = '//js.arcgis.com/3.8/',

//weinreUrl: String
//    weinre is a tool which can help debug the app on mobile devices.
//    Please see: http://people.apache.org/~pmuellr/weinre/docs/latest/Home.html
weinreUrl = '//launch.chn.esri.com:8081/target/target-script-min.js',

//debug: Boolean
//    If it's debug mode, the app will load weinre file
debug = false;
