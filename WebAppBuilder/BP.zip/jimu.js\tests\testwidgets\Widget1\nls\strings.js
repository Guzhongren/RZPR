define({
  root: {
    msg1: "111"
  }
});