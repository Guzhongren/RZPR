﻿define({
  ok: "确定",
  cancel: "取消",
  exportMessage: "导出数据到CSV文件？",
  exportFiles: "导出为CSV文件",
  options: "选项",
  zoomto: "缩放到",
  highlight: "高亮选中元素",
  selectAll: "选择所有页面",
  selectPage: "选择当前页面",
  clearSelection: "清除选择",
  filterByExtent: "当前地图范围过滤",
  refresh: "刷新",
  selected: "已选中",
  transparent: "透明模式",
  columns: "显示/隐藏列",
  selectionSymbol: "选择集符号设置",
  dataNotAvailable: "数据不存在<br>尝试按【刷新】按钮"
});