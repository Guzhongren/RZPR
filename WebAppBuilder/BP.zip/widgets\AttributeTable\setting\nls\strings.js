define({
  root: {
    label: "Layer",
    show: "Show",
    actions: "Selection Symbol",
    field: "Field",
    alias: "Alias",
    visible: "Visible",
    linkField: "LinkField",
    noLayers: "No feature layers available",
    back: "Back",
    exportCSV: "Export to CSV",
    restore: "Restore to default value",
    ok: "OK",
    result: "Save successfully",
    warning: "Check to show this layer in table firstly."
  },
  "zh-cn": true
});