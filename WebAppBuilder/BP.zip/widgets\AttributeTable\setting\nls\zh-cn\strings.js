﻿define({
  label: "图层",
  show: "显示",
  actions: "选择集符号设置",
  field: "字段",
  alias: "别名",
  visible: "是否可见",
  linkField: "Link字段",
  noLayers: "无图层",
  exportCSV: "导出到CSV",
  back: "返回",
  restore: "恢复到缺省值",
  ok: "确定",
  result: "保存成功",
  warning: "必须先选择显示这个图层。"
});