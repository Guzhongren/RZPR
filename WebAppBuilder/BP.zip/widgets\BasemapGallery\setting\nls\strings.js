define({
  root: {
    showArcgisBasemaps: "Show ArcGIS Basemaps",
    add: "Add a new basemap",
    title: "Title",
    thumbnail: "Thumbnail",
    thumbnailHint: "Click image to update",
    url: "URL",
    actions: "Actions",
    warning: "Incorrect input",
    save: "Back and Save",
    back: "Back and Cancel",
    addUrl: "Add URL",
    autoCheck: "Auto Check",
    checking: "Checking...",
    ok: "OK",
    result: "Save successfully",
    spError: "All basemaps added to the gallery need to have the same spatial reference."
  },
  "zh-cn": true
});