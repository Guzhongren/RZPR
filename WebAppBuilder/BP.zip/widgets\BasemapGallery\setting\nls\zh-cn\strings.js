﻿define({
  showArcgisBasemaps: "显示ArcGIS底图",
  add: "添加新底图",
  title: "名称",
  thumbnail: "缩略图",
  thumbnailHint: "请单击缩略图更新",
  url: "URL",
  actions: "操作",
  warning: "错误的输入",
  save: "返回并保存",
  back: "返回并放弃",
  addUrl: "添加URL",
  autoCheck: "自动检查",
  checking: "正在检查...",
  ok: "确定",
  result: "保存成功",
  spError: "所有需要加入BasemapGallery的图层的空间参考必须跟底图保持一致。"
});