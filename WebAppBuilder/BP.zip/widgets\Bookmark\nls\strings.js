define({
  root: {
    labelBookmarkName: "Bookmark the current view",
    labelPlay: "Play All",
    labelStop: "Stop",
    labelDelete: "Delete",
    placeholderBookmarkName: "Bookmark Name",
    errorNameExist: "Bookmark exists!",
    errorNameNull: "Invalid bookmark name!"
  },
  "zh-cn": true
});