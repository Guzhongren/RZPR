﻿define({
  labelBookmarkName: "保存当前视图",
  labelPlay: "播放全部",
  labelStop: "停止",
  labelDelete: "删除",
  placeholderBookmarkName: "书签名称",
  errorNameExist: "名称已存在。",
  errorNameNull: "无效的书签名!"
});