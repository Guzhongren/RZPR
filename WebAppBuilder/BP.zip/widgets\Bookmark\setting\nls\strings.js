define({
  root: {
    placeholderBookmarkName: "Bookmark Name",
    ok: "Ok",
    errorNameExist: "Bookmark exists!",
    errorNameNull: "Invalid bookmark name!",
    addBookmark: "Create a New Bookmark"
  },
  "zh-cn": true
});