﻿define({
  labelBookmarkName: "保存当前视图",
  ok: "确定",
  placeholderBookmarkName: "书签名称",
  errorNameExist: "名称存在。",
  addBookmark: "创建新书签"
});