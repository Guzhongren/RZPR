define({
  root: {
    select: "Select",
    results: "Results",
    selectLayer: "Select from layer:",
    selectDrawtool: "Select draw tool:",
    result: "Result:",
    noresult: "No query results to display chart.",
    nomedia: "There's no media in configuration!",
    envelop: "Draw Rectangle",
    circle: "Draw Circle",
    ellipse: "Draw Ellipse",
    polygon: "Draw Polygon",
    freehand: "Draw Freehand Polygon",
    clear:"Clear"
  },
  "zh-cn": true
});