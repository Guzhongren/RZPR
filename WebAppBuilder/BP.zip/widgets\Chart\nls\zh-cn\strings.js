define({
  select: "选择",
  results: "结果",
  selectLayer: "从图层选择:",
  selectDrawtool: "选择绘制工具:",
  result: "结果:",
  noresult: "查询结果为空。",
  nomedia: "配置文件中没有配置media项！",
  envelop: "画矩形",
  circle: "画圆",
  ellipse: "画椭圆",
  polygon: "画多边形",
  freehand: "手绘多边形",
  clear:"清除"
});