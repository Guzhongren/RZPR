define({
	root: {
		addUrlChartSource:"Add a URL Chart Source",
		addLayerChartSource:"Add a Layer Chart Source",
		sourceLabel:"Source label",
		categoryField:"Category field",
		actions:"Actions",
		hightLightColor:"Highlight color",
		urlChartSource:"URL Chart Source",
		layerChartSource:"Layer Chart Source",
		searchUrl:"Search URL",
		browse:"Browse",
		layers:"Layers",
		availableFields:"Available Fields",
		charts:"Charts",
		chartField:"Chart field",
		description:"Description",
		title:"Title",
		type:"Type",
		cancel:"Cancel",
		addChartSource:"Add Chart Source",
		updateChartSource:"Update Chart Source",
		chartSources:"Chart Sources",
		chartSource:"Chart Source",
		general:"General"
	},
	"zh-cn": true
});