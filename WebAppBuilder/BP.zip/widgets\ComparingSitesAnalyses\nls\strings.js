define({
  root: {
    widgetTitle: "Comparing Sites Analyses" ,
    description: "A custom Web AppBuilder widget."
  }
  // add supported locales below:
  // , "zh-cn": true
});
