﻿define({
  hintMessage: "单击地图获取坐标值",
  defaultLabel: "默认选项",
  computing: "正在计算...",
  latitudeLabel: "纬度",
  longitudeLabel: "经度"
});