define({
	root: {
    addDistance:"Add Distance",
    addArea:"Add Area",
    label:"Label",
    abbr:"Abbreviation",
    conversion:"Conversion",
    actions:"Actions",
		areaUnits:"Area Units",
    distanceUnits:"Distance Units",
    kilometers:'Kilometers',
    miles:'Miles',
    meters:'Meters',
    feet:'Feet',
    yards:'Yards',
    squareKilometers:'Square kilometers',
    squareMiles:'Square miles',
    acres:'Acres',
    hectares:'Hectares',
    squareMeters:'Square meters',
    squareFeet:'Square feet',
    squareYards:'Square yards'
	},
	"zh-cn": true
});