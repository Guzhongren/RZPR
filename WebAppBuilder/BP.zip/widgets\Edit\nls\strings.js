define({
  root: {
    title: "Select template to create feature"
  },
  "zh-cn": true
});