define({
  root: {
    enableUndoRedo: "Enable UndoRedo",
    toolbarVisible: "Toolbar Visible",
    toolbarOptions: "Toolbar Options",
    mergeVisible: "Merge",
    cutVisible: "Cut",
    reshapeVisible: "Reshape",
    back: "Back",
    label: "Layer",
    edit: "Editable",
    update: "UpdateGeometry",
    fields: "Fields",
    actions: "Actions",
    editpageName: "Name",
    editpageAlias: "Alias",
    editpageVisible: "Visible",
    editpageEditable: "Editable",
    noLayers: "No editable feature layers available"
  },
  "zh-cn": true
});