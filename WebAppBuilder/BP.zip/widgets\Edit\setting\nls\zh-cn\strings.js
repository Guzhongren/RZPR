﻿define({
  enableUndoRedo: "启动Undo Redo操作",
  toolbarVisible: "显示工具条",
  toolbarOptions: "工具条选项",
  mergeVisible: "合并",
  cutVisible: "剪切",
  reshapeVisible: "重塑",
  back: "返回",
  label: "图层",
  edit: "是否可编辑",
  update: "修改图形",
  fields: "编辑列",
  actions: "操作",
  editpageName: "字段名",
  editpageAlias: "别名",
  editpageVisible: "是否可见",
  editpageEditable: "是否可编辑",
  noLayers: "没有可编辑的图层。"
});