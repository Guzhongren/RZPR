define({
  root: {
    widgetTitle: "First Widget" ,
    description: "A custom Web AppBuilder widget."
  }
  // add supported locales below:
  // , "zh-cn": true
});
