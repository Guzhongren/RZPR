﻿define({
  appCopyright: "Alle Rechte vorbehalten Esri &copy; 2013"
});