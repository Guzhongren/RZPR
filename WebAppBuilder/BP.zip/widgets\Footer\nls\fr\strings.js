﻿define({
  appCopyright: "Tous droits réservés Esri &copy; 2013"
});