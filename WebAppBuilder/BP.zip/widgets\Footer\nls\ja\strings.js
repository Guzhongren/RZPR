﻿define({
  appCopyright: "All Rights Reserved Esri © 2013"
});