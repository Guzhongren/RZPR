﻿define({
  appCopyright: "Все права защищены. Esri &copy; 2013"
});