define({
  root: {
    appCopyright: "All Rights Reserved Esri &copy; 2013"
  },
  "zh-cn": true,
  "de": true,
  "es": true,
  "fr": true,
  "ja": true,
  "ru": true
});