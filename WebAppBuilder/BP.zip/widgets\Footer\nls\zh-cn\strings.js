﻿define({
  appCopyright: "All Rights Reserved Esri &copy; 2013"
});