define({
  root: {
    placeholder: "Placeholder",
    name: "Name",
    singleLineFieldName: "SingleLineFieldName",
    actions: "Actions",
    warning: "Incorrect input"
  },
  "zh-cn": true
});