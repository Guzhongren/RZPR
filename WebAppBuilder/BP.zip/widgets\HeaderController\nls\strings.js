define({
  root:{
    signin: "Sign In",
    signout: "Sign Out",
    about: "About",
    signInTo: "Sign in to"
  },
  "zh-cn": true
});
