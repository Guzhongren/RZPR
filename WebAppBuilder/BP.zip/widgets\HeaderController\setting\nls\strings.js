define({
  root: {
    group: "Name",
    openAll: "Open All in Panel",
    dropDown: "Show in Drop-down Menu",
    noGroup: "There is no widget group set.",
    groupSetLabel: "Set widget groups properties"
  },
  "zh-cn": true
});