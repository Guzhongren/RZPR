﻿define({
  group: "组名",
  openAll: "在面板中打开全部",
  dropDown: "下拉菜单显示",
  noGroup: "还未设置工具组。",
  groupSetLabel: "设置工具的组属性"
});