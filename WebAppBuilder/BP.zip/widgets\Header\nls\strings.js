define({
  root:{
    signin: "Sign In",
    signout: "Sign Out",
    about: "About"
  },
  "zh-cn": true,
  "de": true,
  "es": true,
  "fr": true,
  "ja": true,
  "ru": true
});
