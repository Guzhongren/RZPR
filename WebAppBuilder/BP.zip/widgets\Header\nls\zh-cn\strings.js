﻿define({
  signin: "登录",
  signout: "注销",
  about: "关于"
});