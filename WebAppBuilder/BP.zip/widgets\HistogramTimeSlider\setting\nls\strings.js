define({
  root: {
    dateFormat: "Date Format",
    mode: "Mode",
    timeInterval: "Time Interval",
    layer: "Layer",
    add: "Add",
    title: "Title",
    actions: "Actions"
  },
  "zh-cn": true
});