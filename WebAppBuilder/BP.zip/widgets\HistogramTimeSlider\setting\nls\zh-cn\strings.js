﻿define({
  dateFormat: "日期格式",
  mode: "模式",
  timeInterval: "时间间隔",
  layer: "图层",
  add: "添加",
  title: "名称",
  actions: "操作"
});