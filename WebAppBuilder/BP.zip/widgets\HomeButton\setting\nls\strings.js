define({
  root: {
    label: "Set the extent where the map will zoom to when user clicks this widget",
    check: "Use map's initial extent"
  },
  "zh-cn": true
});