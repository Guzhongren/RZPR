define({
  root: {
    titleBasemap: 'Base maps',
    titleLayers: 'Operational Layers',
    labelLayer: 'Layer Name',
    itemZoomTo: 'Zoom to',
    itemTransparency: 'Transparency',
    itemTransparent: 'Transparent',
    itemOpaque: 'Opaque',
    itemMoveUp: 'Move up',
    itemMoveDown: 'Move down',
    itemDesc: 'Description',
    itemDownload: 'Download',
    itemToAttributeTable: 'Open attribute table'
  },
  'zh-cn': true
});
