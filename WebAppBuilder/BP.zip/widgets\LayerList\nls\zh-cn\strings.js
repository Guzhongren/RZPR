﻿define({
  titleBasemap: '底图',
  titleLayers: '图层',
  labelLayer: '图层名称',
  itemZoomTo: '缩放',
  itemTransparency: '透明度',
  itemTransparent: '透明',
  itemOpaque: '不透明',
  itemMoveUp: '上移',
  itemMoveDown: '下移',
  itemDesc: '描述',
  itemDownload: '下载',
  itemToAttributeTable: '打开属性表'
});
