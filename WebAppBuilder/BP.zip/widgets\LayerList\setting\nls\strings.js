define({
  root: {
    showLegend: "Show Legend"
  },
  "zh-cn": true
});