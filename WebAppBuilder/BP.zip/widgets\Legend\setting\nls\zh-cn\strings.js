﻿define({
  arrangement: "排列",
  autoUpdate: "自动更新",
  respectCurrentMapScale: "跟随比例自动更新"
});