define({
  root: {
    title: "Find my location",
    browserError: "Geolocation is not supported by this browser.",
    failureFinding: "Can not find your location."
  },
  "zh-cn": true
});