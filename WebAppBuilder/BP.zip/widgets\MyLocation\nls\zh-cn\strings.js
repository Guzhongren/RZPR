﻿define({
  title: "查找我的位置",
  browserError: "该浏览器不支持此功能",
  failureFinding: "无法定位当前位置"
});