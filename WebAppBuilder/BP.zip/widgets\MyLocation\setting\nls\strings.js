define({
  root: {
    timeout: "Timeout",
    highlightLocation: "Highlight location",
    warning: "Incorrect input"
  },
  "zh-cn": true
});