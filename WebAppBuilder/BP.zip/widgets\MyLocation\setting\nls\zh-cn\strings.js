﻿define({
  timeout: "查找位置超时",
  highlightLocation: "高亮所在位置",
  warning: "错误的输入"
});