define({
  root: {
    visible: "Visible",
    minWidth: "Min Width",
    minHeight: "Min Height",
    maxWidth: "Max Width",
    maxHeight: "Max Height",
    minText: "Minimum",
    maxText: "maximum"
  },
  "zh-cn": true
});