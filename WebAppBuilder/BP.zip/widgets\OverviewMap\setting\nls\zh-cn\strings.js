﻿define({
  visible: "显示",
  minWidth: "最小宽度",
  minHeight: "最小高度",
  maxWidth: "最大宽度",
  maxHeight: "最大高度",
  minText: "最小",
  maxText: "最大"
});