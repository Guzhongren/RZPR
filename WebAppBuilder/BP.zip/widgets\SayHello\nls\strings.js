define({
  root: {
    widgetTitle: "Say Hello" ,
    description: "A custom Web AppBuilder widget."
  }
  // add supported locales below:
  // , "zh-cn": true
});
