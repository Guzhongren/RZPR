define({
  root: {
    unit: "Unit",
    style: "Style"
  },
  "zh-cn": true
});