﻿define({
  unit: "单位",
  style: "样式"
});