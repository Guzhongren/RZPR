define({
  root: {
    widgetTitle: "Scene And Review" ,
    description: "A custom Web AppBuilder widget."
  }
  // add supported locales below:
  // , "zh-cn": true
});
