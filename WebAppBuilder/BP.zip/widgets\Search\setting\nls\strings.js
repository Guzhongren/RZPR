define({
	root: {
		settings:"Settings",
		addSearch:"Add a Search",
		searchTitle:"Search Title",
		actions:"Actions",
		zoomScale:"Zoom scale",
		back:"Back",
		searchUrl:"Search URL",
		browse:"Browse",
		title:"Title",
		expression:"Expression",
		searchLabel:"Search label",
		searchHint:"Search hint",
		availableFields:"Available Fields",
		name:"Name",
		alias:"Alias",
		includedFields:"Included Fields",
		cancel:"Cancel",
		addSearch2:"Add Search",
		updateSearch:"Update Search",
		operationalLayerTip:"Add result as operational layer"
	},
	"zh-cn": true
});