﻿define({

    _widgetLabel: "معرض خرائط الأساس"

});