﻿define({

    _widgetLabel: "Aluskaardigalerii"

});