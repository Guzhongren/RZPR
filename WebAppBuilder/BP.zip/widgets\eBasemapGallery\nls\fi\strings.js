﻿define({

    _widgetLabel: "Taustakartat"

});