﻿define({

    _widgetLabel: "גלריית מפות בסיס"

});