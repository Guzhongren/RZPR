﻿define({

    _widgetLabel: "Galleria mappe di base"

});