﻿define({

    _widgetLabel: "Pamatkartes galerija"

});