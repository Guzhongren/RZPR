﻿define({

    _widgetLabel: "Bakgrunnskartgalleri"

});