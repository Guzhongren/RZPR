﻿define({

    _widgetLabel: "Basiskaartgalerij"

});