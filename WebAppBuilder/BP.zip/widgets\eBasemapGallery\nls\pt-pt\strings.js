﻿define({

    _widgetLabel: "Galeria de Mapas Base"

});