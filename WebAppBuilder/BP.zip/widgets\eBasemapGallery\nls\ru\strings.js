﻿define({

    _widgetLabel: "Галерея базовых карт"

});