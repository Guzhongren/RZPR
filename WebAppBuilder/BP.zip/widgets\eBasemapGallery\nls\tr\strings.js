﻿define({

    _widgetLabel: "Altlık Haritası Galerisi"

});